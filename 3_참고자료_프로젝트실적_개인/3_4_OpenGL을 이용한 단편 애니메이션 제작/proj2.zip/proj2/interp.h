#include "base.h"

mat4 get_speed_angle(vec4 p0, vec3 destination, float& speed, float& cosV, float& sinV);
vec3 rand_destination(float rad);