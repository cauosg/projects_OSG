#ifndef FLOWER_H
#define FLOWER_H

class flower
{
public:
	flower();

	void render();
};

#endif // FLOWER_H