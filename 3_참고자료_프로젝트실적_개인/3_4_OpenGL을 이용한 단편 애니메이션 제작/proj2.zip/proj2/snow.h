#ifndef SNOW_H
#define SNOW_H

class snow
{
public:
	snow();
	void init();
	void render();
};

#endif // SNOW_H